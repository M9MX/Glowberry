package org.m9mx.cactus.glowberry.feature.modules;

import com.dwarslooper.cactus.client.feature.module.Category;
import com.dwarslooper.cactus.client.feature.module.Module;
import com.dwarslooper.cactus.client.systems.config.settings.group.SettingGroup;
import com.dwarslooper.cactus.client.systems.config.settings.impl.BooleanSetting;
import com.dwarslooper.cactus.client.systems.config.settings.impl.IntegerSetting;
import com.dwarslooper.cactus.client.systems.config.settings.impl.Setting;

public class HealthIndicatorsModule extends Module {
    public static volatile HealthIndicatorsModule INSTANCE;

    private final SettingGroup generalGroup;
    public final Setting<Boolean> renderingEnabled;
    public final Setting<Boolean> heartStackingEnabled;
    public final Setting<Integer> heartOffset;

    public HealthIndicatorsModule(Category category) {
        super("healthIndicators", category, new Module.Options());
        if (INSTANCE == null) {
            synchronized(HealthIndicatorsModule.class) {
                if (INSTANCE == null) {
                    INSTANCE = this;
                }
            }
        }

        this.generalGroup = this.settings.buildGroup("general");
        this.renderingEnabled = this.generalGroup.add(new BooleanSetting("renderingEnabled", true));
        this.heartStackingEnabled = this.generalGroup.add(new BooleanSetting("heartStackingEnabled", true));
        this.heartOffset = this.generalGroup.add(new IntegerSetting("heartOffset", 0).setMin(-20).setMax(20));
    }

    @Override
    public void onEnable() {
        // Module is enabled, health indicators functionality is active
    }

    @Override
    public void onDisable() {
        // Module is disabled, health indicators functionality is inactive
    }

    // Getter methods for use in mixins
    public boolean isRenderingEnabled() {
        return renderingEnabled.get();
    }

    public boolean isHeartStackingEnabled() {
        return heartStackingEnabled.get();
    }

    public int getHeartOffset() {
        return heartOffset.get();
    }
}